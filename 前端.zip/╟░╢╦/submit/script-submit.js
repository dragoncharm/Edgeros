const password = document.getElementById('password')
const background = document.getElementById('background')

password.addEventListener('input', (e) => {
  const input = e.target.value
  const length = input.length
  const blurValue = 20 - length * 2
  background.style.filter = `blur(${blurValue}px)`
})
// 监听来自父页面的消息
window.addEventListener('message', function(event) {
  // 确保消息来自可信的源
  if (event.origin !== 'https://your-parent-page.com') {
  return;
  }

  // 处理消息
  if (event.data === 'click') {
  // 执行点击操作
  document.getElementById('someElement').click();
  }
});