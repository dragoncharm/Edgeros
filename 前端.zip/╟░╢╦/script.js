// 获取所有导航项和内容区域
const listItems = document.querySelectorAll('nav ul li');
const contents = document.querySelectorAll('.content');
// 初始化时隐藏除第一个页面以外的所有内容区域
hideAllContents();
contents[0].style.display = 'block';

// 将第一个导航项设为激活状态
listItems[0].classList.add('active');
// 为每个导航项添加点击事件监听器
listItems.forEach((item, idx) => {
    item.addEventListener('click', () => {
        // 隐藏所有内容区域
        hideAllContents();

        // 显示当前点击的内容区域
        contents[idx].style.display = 'block';

        // 更新导航项的激活状态
        hideAllItems();
        item.classList.add('active');
    });
});

function hideAllContents() {
    contents.forEach(content => {
        content.style.display = 'none';
    });
}

function hideAllItems() {
    listItems.forEach(item => item.classList.remove('active'));
}